var searchData=
[
  ['platyvg_20libraries',['PlatyVG Libraries',['../index.html',1,'']]]
];
