var searchData=
[
  ['record',['Record',['../class_platy_v_g_core_1_1_record.html',1,'PlatyVGCore']]],
  ['rect',['Rect',['../class_platy_v_g_element_1_1_rect.html',1,'PlatyVGElement']]]
];
