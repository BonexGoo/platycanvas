var searchData=
[
  ['device',['Device',['../class_platy_v_g_core_1_1_device.html',1,'PlatyVGCore']]],
  ['document',['Document',['../class_platy_v_g_core_1_1_document.html',1,'PlatyVGCore']]]
];
