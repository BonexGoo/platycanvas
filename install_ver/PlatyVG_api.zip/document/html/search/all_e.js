var searchData=
[
  ['read',['Read',['../class_px_1_1_file.html#abd77dd916952abba115515d792cd88b0',1,'Px::File']]],
  ['realloc',['Realloc',['../class_px_1_1_buffer.html#a5729c012b7491be06ad6dba8a6ed6b8c',1,'Px::Buffer']]],
  ['record',['Record',['../class_platy_v_g_core_1_1_record.html',1,'PlatyVGCore']]],
  ['rect',['Rect',['../class_platy_v_g_element_1_1_rect.html',1,'PlatyVGElement']]],
  ['redo',['Redo',['../class_platy_v_g_api_1_1_command.html#aff875b1887ef22e458f90bee7d2789cf',1,'PlatyVGApi::Command::Redo()'],['../class_platy_v_g_core_1_1_record.html#ad8bf722191fa454039cdefbeb9936198',1,'PlatyVGCore::Record::Redo()']]],
  ['remove',['Remove',['../class_platy_v_g_api_1_1_command_1_1_canvas.html#a5464d31bdc82557017ed77db748e4cda',1,'PlatyVGApi::Command::Canvas']]],
  ['removeselects',['RemoveSelects',['../class_platy_v_g_api_1_1_command.html#a1ebb82bffcdcff845e04500fc99f1016',1,'PlatyVGApi::Command']]],
  ['renderdib',['RenderDIB',['../class_platy_v_g_api_1_1_adapter.html#a391c2ced09fd77d0cf92fafc75961ff3',1,'PlatyVGApi::Adapter']]],
  ['reset',['Reset',['../class_px_1_1_buffer.html#afa4ac0013039eac758ae07c73978e831',1,'Px::Buffer']]]
];
