var searchData=
[
  ['type',['Type',['../class_px_1_1_array.html#a761685bf155e6fcb3176a216ad10a378',1,'Px::Array']]],
  ['typeof',['TypeOf',['../class_px_1_1_buffer.html#af0325801ad185aa83670d1d231b25bc0',1,'Px::Buffer']]]
];
