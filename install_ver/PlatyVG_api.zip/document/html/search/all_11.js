var searchData=
[
  ['undo',['Undo',['../class_platy_v_g_api_1_1_command.html#a5026d89a6a0d41784bf18fd7ba170896',1,'PlatyVGApi::Command::Undo()'],['../class_platy_v_g_core_1_1_record.html#a6b39259e17b3b72a8851de3a4204c00b',1,'PlatyVGCore::Record::Undo()']]],
  ['union',['Union',['../class_px_1_1_union.html',1,'Px']]],
  ['unlockdynshape',['UnlockDynShape',['../class_platy_v_g_core_1_1_view.html#a2935155fb09a39a7ce5c44dde553c0e4',1,'PlatyVGCore::View']]],
  ['update',['Update',['../class_platy_v_g_api_1_1_command_1_1_canvas.html#aaf541c3e744f5a75154ed13542e7858a',1,'PlatyVGApi::Command::Canvas']]],
  ['updateby',['UpdateBy',['../class_platy_v_g_api_1_1_command_1_1_canvas.html#abdc36cf982fcaa303fd2ebf3e6671247',1,'PlatyVGApi::Command::Canvas']]]
];
