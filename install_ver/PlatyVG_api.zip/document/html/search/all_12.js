var searchData=
[
  ['view',['View',['../class_platy_v_g_core_1_1_view.html',1,'PlatyVGCore']]]
];
