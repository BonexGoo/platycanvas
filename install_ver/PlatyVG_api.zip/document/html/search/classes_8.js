var searchData=
[
  ['layer',['Layer',['../class_platy_v_g_core_1_1_layer.html',1,'PlatyVGCore']]],
  ['listener',['Listener',['../class_platy_v_g_api_1_1_listener.html',1,'PlatyVGApi']]]
];
