var searchData=
[
  ['islayervisibled',['IsLayerVisibled',['../class_platy_v_g_api_1_1_adapter.html#a73136acfdf36e84553831aa479982f40',1,'PlatyVGApi::Adapter']]],
  ['isshapeselected',['IsShapeSelected',['../class_platy_v_g_api_1_1_adapter.html#a512288abac41117e67074e58d42361e8',1,'PlatyVGApi::Adapter']]]
];
