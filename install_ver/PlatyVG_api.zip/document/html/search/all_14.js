var searchData=
[
  ['zoom',['Zoom',['../class_platy_v_g_element_1_1_zoom.html',1,'PlatyVGElement']]]
];
